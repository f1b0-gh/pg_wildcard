#!/usr/bin/env python3
"""Private paired modified-client experiment; never a published-client baseline."""
import sys,json,hashlib,os,statistics,time,subprocess
from pathlib import Path
ROOT=Path('/home/fimbault/codex/pg_wildcard')
sys.path[:0]=[str(ROOT/'tests/benchmarks'),str(ROOT/'libwildcard/tests/benchmarks')]
import sweeps
from route_workers import DirectWorker

def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
    statepath=ROOT/'.local/perf/remaining-issues/antalya.private.json'
    state=json.loads(statepath.read_text())
    worker=ROOT/'.local/review-pg/target/release/compression-perf-worker'
    engine=None;workers={};records=[]
    try:
        engine=sweeps.Engine(str(statepath),timeout_seconds=60)
        engine.query('CREATE TABLE events(id Int64,url String,extra String) ENGINE=MergeTree ORDER BY id')
        engine.query("INSERT INTO events SELECT number,if(number%10000=0,'evil.test/powershell','benign.test/normal'),repeat('x',16) FROM numbers(1000000)")
        engine.query('CREATE TABLE wide_events AS events')
        engine.query("INSERT INTO wide_events SELECT number,'benign.test/normal',repeat('x',1024) FROM numbers(32768)")
        for policy in ['flush_first','in_band']:
            for codec in ['none','zstd']:
                workers[policy,codec]=DirectWorker(worker,state,out/f'{policy}-{codec}.private.log',extra_args=[policy,'16777216',codec])
        revision=subprocess.check_output(['jj','log','-r','@','--no-graph','-T','commit_id'],cwd=ROOT.parent/'antalya-rs',text=True).strip()
        settings=dict(upstream_revision=revision,pending_reservation_bytes={'none':16777216,'zstd':34078720},shared_retained_bytes=67108864,scope='MODIFIED antalya-rs worktree only; paired none vs opt-in zstd; NOT published0.1.0 and NOT PostgreSQL',
            machine=sweeps.machine_settings(),host_load=list(os.getloadavg()),repeats=5,block=4096,batch_bytes=16777216,
            engine=engine.query('SELECT version()')[0][0],engine_cpus=state['cpus'],engine_memory_bytes=state['memory_bytes'],
            worker_sha256=hashlib.sha256(worker.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            clocks='all batches and confirmed outcome, complete values checked on excluded warmup; no query-log diagnostics within timed cohort')
        sources=out/'sources';sources.mkdir()
        for path in [Path(__file__),ROOT/'.local/perf/remaining-issues/compressed-worker/Cargo.toml',ROOT/'.local/perf/remaining-issues/compressed-worker/Cargo.lock',ROOT/'.local/perf/remaining-issues/compressed-worker/src/main.rs',ROOT/'tests/benchmarks/route_workers.py',ROOT/'libwildcard/tests/benchmarks/sweeps.py']:
            (sources/path.name).write_bytes(path.read_bytes())
        (sources/'upstream.patch').write_text(subprocess.check_output(['jj','diff','--git'],cwd=ROOT.parent/'antalya-rs',text=True))
        (out/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
        for workload,rows in [('narrow',1000000),('smalltext',1000000),('wide1k',32768)]:
            table='wide_events' if workload=='wide1k' else 'events'
            projection='id' if workload=='narrow' else 'id,url,extra'
            sql=f'SELECT {projection} FROM {engine.database}.{table}'
            configs=[c for c in workers if workload!='wide1k' or c[0]=='in_band']
            for repeat in range(-1,5):
                rotation=(repeat+1)%len(configs)
                for policy,codec in configs[rotation:]+configs[:rotation]:
                    record=dict(workload=workload,rows=rows,policy=policy,codec=codec,repeat=repeat,sql=sql,host_load=list(os.getloadavg()))
                    (out/'pending.json').write_text(json.dumps(record)+'\n')
                    w=workers[policy,codec]
                    w.process.stdin.write((json.dumps(dict(sql=sql,workload=workload,rows=rows,verify=repeat<0,block_size=4096))+'\n').encode());w.process.stdin.flush()
                    record.update(w.read(75));records.append(record)
                    with (out/'raw.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
                    if 'error' in record:raise RuntimeError('typed worker failure; see private logs')
                    (out/'pending.json').unlink()
                    print(json.dumps({k:record[k] for k in ['workload','policy','codec','repeat','request_ms','http_body_bytes']}),flush=True)
        engine.query('SYSTEM FLUSH LOGS',logging=False)
        ids=','.join("'"+r['query_id']+"'" for r in records)
        logs=engine.query("SELECT query_id,query_duration_ms,read_rows,result_rows,ProfileEvents,Settings FROM system.query_log WHERE type='QueryFinish' AND is_initial_query=1 AND query_id IN ("+ids+")",logging=False)
        (out/'query-log.json').write_text(json.dumps(logs,indent=2)+'\n')
        byid={r[0]:r for r in logs}
        if len(logs)!=len(records) or len(byid)!=len(logs):raise ValueError('incomplete or duplicate profile cohort')
        for record in records:
            row=byid[record['query_id']]
            assert int(row[3])==record['rows'] and row[5]['output_format_arrow_compression_method']==record['codec']
            assert str(row[5]['max_block_size'])=='4096'
            record['profile']=dict(server_ms=row[1],read_rows=row[2],result_rows=row[3],events=row[4],settings=row[5])
        (out/'correlated.json').write_text(json.dumps(records,indent=2)+'\n')
        summary=[]
        for workload in ['narrow','smalltext','wide1k']:
            for policy,codec in workers:
                if workload=='wide1k' and policy!='in_band':continue
                cohort=[r for r in records if r['workload']==workload and r['policy']==policy and r['codec']==codec and r['repeat']>=0]
                summary.append(dict(workload=workload,policy=policy,codec=codec,n=len(cohort),
                    median_ms=statistics.median(r['request_ms'] for r in cohort),
                    median_http_entity_bytes=statistics.median(r['http_body_bytes'] for r in cohort),
                    median_decode_ms=statistics.median(r['arrow_decode_ms'] for r in cohort)))
        (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    except Exception as error:
        (out/'failure.json').write_text(json.dumps(dict(error=sweeps.redact(str(error),state),completed=len(records)))+'\n');raise
    finally:
        failures=[]
        for w in workers.values():
            try:w.close()
            except Exception:failures.append('worker cleanup')
        if engine:
            try:engine.close()
            except Exception:failures.append('owned database cleanup')
        (out/'cleanup.json').write_text(json.dumps(dict(failures=failures))+'\n')
        if failures:raise RuntimeError('cleanup failure')
if __name__=='__main__':main()
